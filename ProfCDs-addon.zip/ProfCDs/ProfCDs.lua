-- Professions CDs Tracker – in-game part
-- 1) Turns on combat logging at login, so the PC helper sees new casts within seconds.
-- 2) Reads each character's profession cooldowns and saves them (WoW writes the file on logout / character switch / reload).
-- Type /profcds in game to see what the addon can see.

local f = CreateFrame("Frame")
local DB
local scanQueued = false

-- Cooldown lengths in seconds (WoW Forever, Nov 2026). Only used until the real cooldown can be read.
local DUR = {
  arcanite = 47 * 3600, legionite = 47 * 3600, elemental = 23 * 3600, onyxia = 2 * 3600, efire = 600,
  ironGold = 3600, mithrilTrue = 3600, salt = 71 * 3600, mooncloth = 95 * 3600, study = 23 * 3600,
}

-- Spells we know the ID of. Others (e.g. Dedicated Study, Legionite) are learned by name
-- the first time they are cast or seen in the profession window.
local SEED_IDS = {
  [17187] = "Transmute: Arcanite", [11479] = "Transmute: Iron to Gold", [11480] = "Transmute: Mithril to Truesilver",
  [17559] = "Transmute: Air to Fire", [17560] = "Transmute: Fire to Earth", [17561] = "Transmute: Earth to Water",
  [17562] = "Transmute: Water to Air", [17563] = "Transmute: Undeath to Water", [17564] = "Transmute: Water to Undeath",
  [17565] = "Transmute: Life to Earth", [17566] = "Transmute: Earth to Life", [25146] = "Transmute: Elemental Fire",
  [18560] = "Mooncloth", [19566] = "Salt Shaker",
}
local NAME_LOOKUPS = { "Dedicated Study", "Transmute: Legionite", "Transmute: Refined Scale of Onyxia" }
local SALT_ITEM = 15846

-- Returns key, variant for a spell/recipe name, or nil.
local function classify(name)
  if type(name) ~= "string" then return nil end
  local t = name:match("^Transmute: (.+)$")
  if t then
    if t == "Iron to Gold" then return "ironGold" end
    if t == "Mithril to Truesilver" then return "mithrilTrue" end
    if t == "Arcanite" then return "transmute", "arcanite" end
    if t == "Legionite" then return "transmute", "legionite" end
    if t == "Elemental Fire" then return "transmute", "efire" end
    if t:find("Onyxia") then return "transmute", "onyxia" end
    return "transmute", "elemental"
  end
  if name == "Salt Shaker" or name == "Refined Deeprock Salt" then return "salt" end
  if name == "Mooncloth" or name == "Create Item: Mooncloth" then return "mooncloth" end
  if name == "Dedicated Study" then return "study" end
  return nil
end

local function isNum(x)
  if type(x) ~= "number" then return false end
  if issecretvalue and issecretvalue(x) then return false end
  return true
end

-- WoW's GetTime() wraps every 2^32 ms (~49.7 days). Long cooldowns that started before the
-- game/PC was started come back with a start time shifted by exactly that amount.
local WRAP = 4294967.296
local MAX_CD = 100 * 3600 -- nothing we track is longer than ~96 hours

-- Seconds left from a (start, duration) pair. nil = unknown, 0 = ready.
local function left(start, dur)
  if not isNum(start) or not isNum(dur) then return nil end
  if dur <= 2 or start == 0 then return 0 end -- nothing or just the global cooldown
  local t = GetTime()
  local guard = 0
  while start > t and guard < 3 do start = start - WRAP; guard = guard + 1 end
  local r = start + dur - t
  if r > dur + 60 or r > MAX_CD then return nil end -- still impossible: ignore rather than show nonsense
  return r > 0 and r or 0
end

local function spellLeft(id)
  if C_Spell and C_Spell.GetSpellCooldown then
    local ok, info = pcall(C_Spell.GetSpellCooldown, id)
    if ok and type(info) == "table" then return left(info.startTime, info.duration) end
  end
  if GetSpellCooldown then
    local ok, s, d = pcall(GetSpellCooldown, id)
    if ok then return left(s, d) end
  end
  return nil
end

local function itemLeft(id)
  local fn = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
  if not fn then return nil end
  local ok, s, d = pcall(fn, id)
  if ok then return left(s, d) end
  return nil
end

local function spellName(id)
  if C_Spell and C_Spell.GetSpellName then
    local ok, n = pcall(C_Spell.GetSpellName, id)
    if ok and type(n) == "string" then return n end
  end
  if GetSpellInfo then local ok, n = pcall(GetSpellInfo, id); if ok and type(n) == "string" then return n end end
  return nil
end

local function me()
  local name, realm = UnitFullName("player")
  realm = realm or GetRealmName() or ""
  local id = name .. "-" .. realm
  DB.chars[id] = DB.chars[id] or { name = name, realm = realm, known = {}, cds = {} }
  return DB.chars[id]
end

local function now() return GetServerTime() end

-- Record a cooldown for the current character. secondsLeft = 0 means ready.
local function record(c, key, secondsLeft, variant)
  local t = now()
  local cd = c.cds[key] or {}
  cd.readyAt = secondsLeft > 0 and math.floor(t + secondsLeft) or 0
  if variant then cd.variant = variant end
  cd.observed = t
  c.cds[key] = cd
  if secondsLeft > 0 then c.known[key] = true end
end

local function buildExport()
  local lines = {}
  for _, c in pairs(DB.chars) do
    for key in pairs(c.known) do
      local cd = c.cds[key] or {}
      lines[#lines + 1] = table.concat({ c.name, c.realm, key, cd.variant or "", tostring(cd.readyAt or 0), tostring(cd.observed or 0) }, "|")
    end
  end
  DB.export = table.concat(lines, ";")
  DB.exportedAt = now()
end

local function scan()
  if not DB then return end
  local c = me()
  -- Make sure name lookups have turned into IDs.
  for _, n in ipairs(NAME_LOOKUPS) do
    if C_Spell and C_Spell.GetSpellInfo then
      local ok, info = pcall(C_Spell.GetSpellInfo, n)
      if ok and type(info) == "table" and isNum(info.spellID) then DB.learned[info.spellID] = n end
    end
  end
  local best = {} -- key -> {left, variant}
  local function consider(key, l, variant)
    if l == nil then return end
    local b = best[key]
    if not b or l > b.left then best[key] = { left = l, variant = variant } end
  end
  for id, n in pairs(SEED_IDS) do local key, v = classify(n); consider(key, spellLeft(id), nil) end
  for id, n in pairs(DB.learned) do local key, v = classify(n); consider(key, spellLeft(id), nil) end
  consider("salt", itemLeft(SALT_ITEM), nil)

  for key, b in pairs(best) do
    local fr = c.fromRecipe and c.fromRecipe[key]
    if fr and now() - fr < 10 then
      -- the profession window just gave us this value directly; keep it
    elseif b.left > 0 then
      record(c, key, b.left, nil)            -- running: the character clearly has it
    elseif c.known[key] then
      record(c, key, 0, nil)                 -- ready, and we know this character has it
    end
  end
  buildExport()
end

-- Profession window: learn which recipes this character has, and their cooldowns.
local function scanTradeSkill()
  if not (C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs) then return end
  local ok, ids = pcall(C_TradeSkillUI.GetAllRecipeIDs)
  if not ok or type(ids) ~= "table" then return end
  local c = me()
  c.tradeOpened = true
  for _, rid in ipairs(ids) do
    local ok2, info = pcall(C_TradeSkillUI.GetRecipeInfo, rid)
    if ok2 and type(info) == "table" and info.learned then
      local key, variant = classify(info.name)
      if key then
        DB.learned[rid] = info.name
        c.known[key] = true
        if C_TradeSkillUI.GetRecipeCooldown then
          local ok3, cd = pcall(C_TradeSkillUI.GetRecipeCooldown, rid)
          if ok3 and isNum(cd) and cd > 0 and cd < MAX_CD then record(c, key, cd, nil); c.fromRecipe = c.fromRecipe or {}; c.fromRecipe[key] = now() end
        end
      end
    end
  end
  scan()
end

local function enableCombatLog()
  if not LoggingCombat then return end
  local ok, on = pcall(LoggingCombat)
  if ok and not on then pcall(LoggingCombat, true) end
end

local onTrackedCast -- set further down (send-to-phone popup)

local function onCast(spellID)
  local n = spellName(spellID)
  local key, variant = classify(n)
  if not key then return end
  DB.learned[spellID] = n
  local c = me()
  c.known[key] = true
  record(c, key, DUR[variant or key] or DUR[key], variant)
  buildExport()
  C_Timer.After(2, scan) -- replace the estimate with the real cooldown
  if onTrackedCast then onTrackedCast(key, variant) end
end

f:SetScript("OnEvent", function(_, event, ...)
  if event == "ADDON_LOADED" then
    if ... == "ProfCDs" then
      ProfCDsDB = ProfCDsDB or {}
      DB = ProfCDsDB
      DB.chars = DB.chars or {}
      DB.learned = DB.learned or {}
      DB.version = 1
    end
  elseif event == "PLAYER_ENTERING_WORLD" then
    enableCombatLog()
    C_Timer.After(3, scan)
  elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
    local unit, _, spellID = ...
    if unit == "player" and isNum(spellID) then onCast(spellID) end
  elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_LIST_UPDATE" then
    C_Timer.After(0.5, scanTradeSkill)
  elseif event == "SPELL_UPDATE_COOLDOWN" or event == "BAG_UPDATE_COOLDOWN" then
    if not InCombatLockdown() then
      if not scanQueued then scanQueued = true; C_Timer.After(2, function() scanQueued = false; scan() end) end
    end
  elseif event == "PLAYER_LOGOUT" then
    if DB then pcall(scan) end
  end
end)
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "UNIT_SPELLCAST_SUCCEEDED", "TRADE_SKILL_SHOW",
  "TRADE_SKILL_LIST_UPDATE", "SPELL_UPDATE_COOLDOWN", "BAG_UPDATE_COOLDOWN", "PLAYER_LOGOUT" }) do
  pcall(f.RegisterEvent, f, e)
end

-- Forward declarations (defined further down, used by the windows and the minimap button)
local sendSettings, toggleMenu
local pending = {}

local NICE = { transmute = "Transmute", ironGold = "Iron to Gold", mithrilTrue = "Mithril to Truesilver", salt = "Salt Shaker", mooncloth = "Mooncloth", study = "Dedicated Study" }
local GOLD, GREEN, RED, GREY = "|cffd9b35f", "|cff6fd39a", "|cffe2736a", "|cff9a98a3"
local function fmt(s)
  if s <= 0 then return GREEN .. "Ready|r" end
  local h = math.floor(s / 3600); local m = math.floor((s % 3600) / 60)
  if h >= 24 then return string.format("%dd %dh %02dm", math.floor(h / 24), h % 24, m) end
  return string.format("%dh %02dm", h, m)
end
local function loggingOn() if not LoggingCombat then return false end local ok, on = pcall(LoggingCombat); return ok and on end
local function hasProfessions()
  if not GetProfessions then return true end
  local ok, a, b = pcall(GetProfessions)
  return ok and (a ~= nil or b ~= nil)
end

local WELCOME = table.concat({
  GOLD .. "Welcome!|r This addon sends your profession cooldowns to the",
  "Professions CDs Tracker app on your phone, so you get a notification",
  "when a transmute, Salt Shaker, Mooncloth or Dedicated Study is ready.",
  "",
  GOLD .. "What you need to do|r",
  "1. On each character with a profession: " .. GOLD .. "open the profession window once|r.",
  "   That lets the addon see which recipes the character has.",
  "2. Play as usual. Use your cooldowns like you always do.",
  "",
  GOLD .. "What happens by itself|r",
  "- Combat logging is turned on at login (the PC helper reads it).",
  "- When you log out or switch character, all cooldowns of that",
  "  character are saved and sent too (this is also how cooldowns",
  "  that were already running get picked up the first time).",
  "",
  GOLD .. "The tracker window|r",
  "- A small window shows all your characters' cooldowns, live.",
  "  Drag it where you want it. It keeps tracking even when hidden.",
  "- Show/hide it with the " .. GOLD .. "minimap button|r (left-click) or " .. GOLD .. "/cds|r.",
  "- " .. GOLD .. "Right-click|r the minimap button for a menu: send to phone,",
  "  status and settings. " .. GOLD .. "/cds status|r also shows details.",
  "",
  GOLD .. "Sending to your phone|r",
  "- After you use a cooldown, a small window asks: " .. GOLD .. "Send now|r or " .. GOLD .. "Later|r.",
  "  Send now: one click, your phone updates within about 30 seconds.",
  "  Later: it is sent on your next logout, character switch or reload.",
  "- Don't want the question? Tick \"Don't ask again\" - you can still send",
  "  from the minimap menu, and switch the question back on there.",
  "- " .. GOLD .. "/cds lock|r / " .. GOLD .. "/cds unlock|r locks the window in place.",
  "",
  GOLD .. "Good to know|r",
  "- The PC helper must be installed (install.cmd) and use the same",
  "  sync code as the app.",
}, "\n")

local frame
local function getFrame()
  if frame then return frame end
  local ok, fr = pcall(CreateFrame, "Frame", "ProfCDsFrame", UIParent, "BasicFrameTemplateWithInset")
  if not ok or not fr then ok, fr = pcall(CreateFrame, "Frame", "ProfCDsFrame", UIParent, "BackdropTemplate") end
  if not ok or not fr then return nil end
  frame = fr
  fr:SetSize(470, 640)
  fr:SetPoint("CENTER")
  fr:SetFrameStrata("DIALOG")
  fr:SetMovable(true); fr:EnableMouse(true); fr:RegisterForDrag("LeftButton")
  fr:SetScript("OnDragStart", fr.StartMoving); fr:SetScript("OnDragStop", fr.StopMovingOrSizing)
  if fr.SetBackdrop and not fr.TitleBg then
    fr:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32, insets = { left = 8, right = 8, top = 8, bottom = 8 } })
  end
  fr.title = fr:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  fr.title:SetPoint("TOP", 0, -6)
  fr.title:SetText("Professions CDs Tracker")
  fr.body = fr:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fr.body:SetPoint("TOPLEFT", 18, -36)
  fr.body:SetPoint("RIGHT", -18, 0)
  fr.body:SetJustifyH("LEFT"); fr.body:SetJustifyV("TOP")
  if fr.body.SetSpacing then fr.body:SetSpacing(3) end
  fr.btn = CreateFrame("Button", nil, fr, "UIPanelButtonTemplate")
  fr.btn:SetSize(120, 24); fr.btn:SetPoint("BOTTOMRIGHT", -16, 14)
  fr.btn:SetText("Got it"); fr.btn:SetScript("OnClick", function() fr:Hide() end)
  fr.help = CreateFrame("Button", nil, fr, "UIPanelButtonTemplate")
  fr.help:SetSize(120, 24); fr.help:SetPoint("BOTTOMLEFT", 16, 14)
  if UISpecialFrames then table.insert(UISpecialFrames, "ProfCDsFrame") end
  return fr
end

local showStatus, showWelcome
showWelcome = function()
  local fr = getFrame()
  if not fr then print(WELCOME) return end
  fr.body:SetText(WELCOME)
  fr.help:SetText("Show status"); fr.help:SetScript("OnClick", function() showStatus() end)
  fr:Show()
end

showStatus = function()
  scan()
  local c = me()
  local lines = {}
  local function add(x) lines[#lines + 1] = x end
  add(GOLD .. "Status for " .. c.name .. "|r")
  add("")
  add((loggingOn() and (GREEN .. "[OK]|r Combat logging is on") or (RED .. "[!]|r Combat logging is off - type /combatlog")))
  if c.tradeOpened then add(GREEN .. "[OK]|r Profession window has been opened on this character")
  elseif hasProfessions() then add(RED .. "[!]|r Open your profession window once on this character")
  else add(GREY .. "[-]|r This character has no profession") end
  add("")
  add(GOLD .. "Cooldowns seen|r")
  local any = false
  for key in pairs(c.known) do
    local cd = c.cds[key] or {}
    add("  " .. (NICE[key] or key) .. (cd.variant and (GREY .. " (" .. cd.variant .. ")|r") or "") .. ":  " .. fmt((cd.readyAt or 0) - now()))
    any = true
  end
  if not any then add(GREY .. "  None yet. Open the profession window, or use a cooldown.|r") end
  add("")
  local others = 0
  for id, oc in pairs(DB.chars) do if oc ~= c then for _ in pairs(oc.known) do others = others + 1; break end end end
  add(GOLD .. "Sending to your phone|r")
  local ss = sendSettings()
  add("  New cooldowns: when you click " .. GOLD .. "Send now|r (popup or minimap menu).")
  add("  Everything on this character: when you log out, switch character or reload.")
  add("  Ask after each cooldown: " .. (ss.askAfterCast and (GREEN .. "ON|r") or (GREY .. "OFF|r")) ..
      "    Send method: " .. (ss.sendMethod == "reload" and "Reload" or "Background"))
  add("  Other characters with cooldowns saved: " .. others)
  add("")
  add(GREY .. "Tracker: /cds or left-click the minimap button.  Menu: right-click it.|r")
  add(GREY .. "Not updating on the phone? Check that the PC helper is installed and uses|r")
  add(GREY .. "the same sync code as the app (app: Settings > Sync with WoW).|r")
  local fr = getFrame()
  if not fr then for _, l in ipairs(lines) do print(l) end return end
  fr.body:SetText(table.concat(lines, "\n"))
  fr.help:SetText("How it works"); fr.help:SetScript("OnClick", function() showWelcome() end)
  fr:Show()
end

-- ---------- Tracker window (always available; tracking runs whether it is shown or not) ----------
local tracker, trackerRows = nil, {}
local function trackerSettings()
  DB.tracker = DB.tracker or { shown = true, locked = false }
  return DB.tracker
end

local function savePos(fr)
  local p, _, rp, x, y = fr:GetPoint()
  trackerSettings().pos = { p, rp, x, y }
end

local function buildTracker()
  if tracker then return tracker end
  local ok, fr = pcall(CreateFrame, "Frame", "ProfCDsTracker", UIParent, "BackdropTemplate")
  if not ok or not fr then return nil end
  tracker = fr
  fr:SetSize(260, 60)
  local pos = trackerSettings().pos
  if pos then fr:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4]) else fr:SetPoint("RIGHT", UIParent, "RIGHT", -60, 140) end
  fr:SetFrameStrata("MEDIUM")
  fr:SetClampedToScreen(true)
  if fr.SetBackdrop then
    fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    fr:SetBackdropColor(0.07, 0.08, 0.11, 0.85)
    fr:SetBackdropBorderColor(0.85, 0.70, 0.37, 0.55)
  end
  fr:SetMovable(true); fr:EnableMouse(true); fr:RegisterForDrag("LeftButton")
  fr:SetScript("OnDragStart", function(self) if not trackerSettings().locked then self:StartMoving() end end)
  fr:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); savePos(self) end)
  fr.title = fr:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fr.title:SetPoint("TOPLEFT", 10, -8)
  fr.title:SetText(GOLD .. "Profession CDs|r")
  local close = CreateFrame("Button", nil, fr, "UIPanelCloseButton")
  close:SetSize(22, 22); close:SetPoint("TOPRIGHT", 2, 2)
  close:SetScript("OnClick", function()
    fr:Hide(); trackerSettings().shown = false
    print(GOLD .. "Professions CDs:|r tracker hidden – still tracking in the background. Show it again with the minimap button or /cds.")
  end)
  return fr
end

local function updateTracker()
  if not tracker or not tracker:IsShown() then return end
  local list, t, mine = {}, now(), me()
  for _, c in pairs(DB.chars) do
    for key in pairs(c.known) do
      local cd = c.cds[key] or {}
      list[#list + 1] = { who = c.name, what = NICE[key] or key, left = (cd.readyAt or 0) - t, mine = (c == mine) }
    end
  end
  table.sort(list, function(a, b) if a.left ~= b.left then return a.left < b.left end return a.who < b.who end)
  if #list == 0 then list[1] = { who = "", what = GREY .. "No cooldowns yet – open a profession window|r", left = nil } end
  for i, e in ipairs(list) do
    local r = trackerRows[i]
    if not r then
      r = { l = tracker:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"), r = tracker:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") }
      r.l:SetJustifyH("LEFT"); r.r:SetJustifyH("RIGHT")
      trackerRows[i] = r
    end
    local y = -28 - (i - 1) * 16
    r.l:ClearAllPoints(); r.l:SetPoint("TOPLEFT", 10, y)
    r.r:ClearAllPoints(); r.r:SetPoint("TOPRIGHT", -10, y)
    local who = e.who ~= "" and ((e.mine and GOLD or "|cffece6d8") .. e.who .. "|r  ") or ""
    r.l:SetText(who .. (e.left and (GREY .. e.what .. "|r") or e.what))
    r.r:SetText(e.left and fmt(e.left) or "")
    r.l:Show(); r.r:Show()
  end
  for i = #list + 1, #trackerRows do trackerRows[i].l:Hide(); trackerRows[i].r:Hide() end
  tracker:SetHeight(36 + #list * 16)
end

local function setTrackerShown(show)
  local fr = buildTracker()
  if not fr then return end
  trackerSettings().shown = show
  if show then fr:Show(); updateTracker() else fr:Hide() end
end
local function toggleTracker()
  local fr = buildTracker()
  if fr then setTrackerShown(not fr:IsShown()) end
end

-- ---------- Minimap button ----------
local function placeMinimapButton(b)
  local a = math.rad(trackerSettings().minimapAngle or 210)
  local r = (Minimap:GetWidth() / 2) + 8
  b:ClearAllPoints()
  b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end
local function buildMinimapButton()
  if not Minimap or _G.ProfCDsMinimapButton then return end
  local ok, b = pcall(CreateFrame, "Button", "ProfCDsMinimapButton", Minimap)
  if not ok or not b then return end
  b:SetSize(31, 31); b:SetFrameStrata("MEDIUM"); b:SetFrameLevel(8)
  local icon = b:CreateTexture(nil, "BACKGROUND")
  icon:SetTexture("Interface\\Icons\\Trade_Alchemy"); icon:SetSize(20, 20); icon:SetPoint("CENTER", 0, 1)
  local border = b:CreateTexture(nil, "OVERLAY")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); border:SetSize(53, 53); border:SetPoint("TOPLEFT")
  b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:RegisterForDrag("LeftButton")
  b:SetScript("OnClick", function(self, btn) if btn == "RightButton" then toggleMenu(self) else toggleTracker() end end)
  b:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      local mx, my = Minimap:GetCenter()
      local cx, cy = GetCursorPosition()
      local sc = Minimap:GetEffectiveScale()
      trackerSettings().minimapAngle = math.deg(math.atan2(cy / sc - my, cx / sc - mx))
      placeMinimapButton(self)
    end)
  end)
  b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  b:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Professions CDs Tracker")
    GameTooltip:AddLine("Left-click: show/hide the tracker", 1, 1, 1)
    GameTooltip:AddLine("Right-click: menu (send to phone, status, settings)", 1, 1, 1)
    if #pending > 0 then GameTooltip:AddLine(#pending .. " cooldown(s) not sent to your phone yet", 0.85, 0.70, 0.37) end
    GameTooltip:AddLine("Drag: move this button", 0.6, 0.6, 0.6)
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  placeMinimapButton(b)
end

-- ---------- Send to phone ----------
-- WoW only writes the combat log to disk when the player turns logging off/on themselves (or on
-- logout/reload). A secure button runs "/combatlog" twice as if typed, so one click sends.
local SEND_MACRO = { log = "/combatlog\n/combatlog", reload = "/reload" }
local sendButtons, hideChatUntil = {}, 0
local popup, menu
local popupWanted, popupShownAt = false, 0
local hideAfterCombat, lastSendMsg = {}, 0

sendSettings = function()
  local t = trackerSettings()
  if t.askAfterCast == nil then t.askAfterCast = true end
  t.sendMethod = (t.sendMethod == "reload") and "reload" or "log"
  return t
end

local function pendingText()
  local names = {}
  for _, p in ipairs(pending) do names[#names + 1] = p end
  if #names == 0 then return "Send your latest cooldowns to your phone." end
  if #names == 1 then return names[1] .. " used." end
  return #names .. " cooldowns used: " .. table.concat(names, ", ") .. "."
end

local function safeHide(fr)
  if not fr or not fr:IsShown() then return end
  if InCombatLockdown() then popupWanted = false; hideAfterCombat[fr] = true; return end
  fr:Hide()
end

local function afterSend()
  if sendSettings().sendMethod == "reload" then return end -- the reload takes over
  if #pending == 0 and GetTime() - lastSendMsg < 2 then return end
  wipe(pending)
  lastSendMsg = GetTime()
  safeHide(popup); safeHide(menu)
  print(GOLD .. "Professions CDs:|r sent – your phone updates within about 30 seconds.")
end

local function updateSendMacros()
  if InCombatLockdown() then return end
  local m = SEND_MACRO[sendSettings().sendMethod]
  for _, b in ipairs(sendButtons) do b:SetAttribute("macrotext", m) end
end

local function makeSendButton(parent, w, h, label)
  local ok, b = pcall(CreateFrame, "Button", nil, parent, "SecureActionButtonTemplate, UIPanelButtonTemplate")
  if not ok or not b then return nil end
  b:SetSize(w, h); b:SetText(label)
  b:RegisterForClicks("AnyUp", "AnyDown")
  b:SetAttribute("type", "macro")
  b:SetAttribute("macrotext", SEND_MACRO[sendSettings().sendMethod])
  b:HookScript("PreClick", function() hideChatUntil = GetTime() + 3 end)
  b:HookScript("PostClick", function() C_Timer.After(0.3, afterSend) end)
  sendButtons[#sendButtons + 1] = b
  return b
end

-- Hide the "Combat logging disabled/enabled" lines that our own send produces.
local function chatFilter(_, _, msg)
  if GetTime() > hideChatUntil or type(msg) ~= "string" then return false end
  local ok, hit = pcall(function()
    return msg == _G.COMBATLOGDISABLED or msg == _G.COMBATLOGENABLED or msg:lower():find("combat") ~= nil
  end)
  return ok and hit or false
end
if ChatFrame_AddMessageEventFilter then pcall(ChatFrame_AddMessageEventFilter, "CHAT_MSG_SYSTEM", chatFilter)
elseif ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter then pcall(ChatFrameUtil.AddMessageEventFilter, "CHAT_MSG_SYSTEM", chatFilter) end

local function buildPopup()
  if popup then return popup end
  local ok, fr = pcall(CreateFrame, "Frame", "ProfCDsSendPopup", UIParent, "BackdropTemplate")
  if not ok or not fr then return nil end
  popup = fr
  fr:SetSize(320, 128); fr:SetPoint("TOP", UIParent, "TOP", 0, -150); fr:SetFrameStrata("DIALOG")
  if fr.SetBackdrop then
    fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    fr:SetBackdropColor(0.07, 0.08, 0.11, 0.95); fr:SetBackdropBorderColor(0.85, 0.70, 0.37, 0.8)
  end
  fr.title = fr:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fr.title:SetPoint("TOPLEFT", 12, -10); fr.title:SetText(GOLD .. "Send to your phone?|r")
  fr.body = fr:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fr.body:SetPoint("TOPLEFT", 12, -30); fr.body:SetPoint("RIGHT", -12, 0); fr.body:SetJustifyH("LEFT")
  fr.send = makeSendButton(fr, 130, 24, "Send now")
  if fr.send then fr.send:SetPoint("BOTTOMLEFT", 12, 34) end
  fr.later = CreateFrame("Button", nil, fr, "UIPanelButtonTemplate")
  fr.later:SetSize(130, 24); fr.later:SetPoint("BOTTOMRIGHT", -12, 34); fr.later:SetText("Later")
  fr.later:SetScript("OnClick", function() fr:Hide() end)
  local okc, cb = pcall(CreateFrame, "CheckButton", nil, fr, "UICheckButtonTemplate")
  if okc and cb then
    cb:SetSize(22, 22); cb:SetPoint("BOTTOMLEFT", 8, 6)
    local t = (type(cb.text) == "table" and cb.text) or (type(cb.Text) == "table" and cb.Text) or cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    t:ClearAllPoints(); t:SetPoint("LEFT", cb, "RIGHT", 2, 0); t:SetText(GREY .. "Don't ask again (send from the minimap menu)|r")
    cb:SetScript("OnClick", function(self)
      sendSettings().askAfterCast = not self:GetChecked()
      if self:GetChecked() then print(GOLD .. "Professions CDs:|r won't ask anymore. Right-click the minimap button to send, or to turn the question back on.") end
    end)
    fr.dontAsk = cb
  end
  return fr
end

local function showPopup()
  if not sendSettings().askAfterCast or #pending == 0 then return end
  if InCombatLockdown() then popupWanted = true; return end
  local fr = buildPopup()
  if not fr then return end
  local how = sendSettings().sendMethod == "reload" and "a quick reload" or "no loading screen"
  fr.body:SetText(pendingText() .. "\nSend now updates your phone (" .. how .. ").\nLater: sent on your next logout, character switch or reload.")
  if fr.dontAsk then fr.dontAsk:SetChecked(false) end
  fr:Show()
  popupShownAt = GetTime()
  local shownAt = popupShownAt
  C_Timer.After(30, function() if popup and popupShownAt == shownAt then safeHide(popup) end end) -- ignored = Later
end

onTrackedCast = function(key, variant)
  local name = NICE[key] or key
  if key == "transmute" and variant then name = "Transmute (" .. variant .. ")" end
  for _, p in ipairs(pending) do if p == name then name = nil; break end end
  if name then pending[#pending + 1] = name end
  C_Timer.After(2.5, showPopup)
end

-- Minimap right-click menu
local function buildMenu(anchor)
  if menu then return menu end
  local ok, fr = pcall(CreateFrame, "Frame", "ProfCDsMenu", UIParent, "BackdropTemplate")
  if not ok or not fr then return nil end
  menu = fr
  fr:SetSize(220, 160); fr:SetFrameStrata("DIALOG"); fr:SetClampedToScreen(true)
  if fr.SetBackdrop then
    fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    fr:SetBackdropColor(0.07, 0.08, 0.11, 0.95); fr:SetBackdropBorderColor(0.85, 0.70, 0.37, 0.8)
  end
  local y = -10
  local function place(b) b:SetPoint("TOP", fr, "TOP", 0, y); y = y - 28 end
  fr.send = makeSendButton(fr, 196, 24, "Send to phone now")
  if fr.send then place(fr.send) end
  local function btn(label, fn)
    local b = CreateFrame("Button", nil, fr, "UIPanelButtonTemplate")
    b:SetSize(196, 24); b:SetText(label); b:SetScript("OnClick", fn); place(b); return b
  end
  btn("Show / hide tracker", function() toggleTracker(); fr:Hide() end)
  btn("Status", function() fr:Hide(); showStatus() end)
  fr.ask = btn("", function() local s2 = sendSettings(); s2.askAfterCast = not s2.askAfterCast; fr.refresh() end)
  fr.method = btn("", function()
    if InCombatLockdown() then return end
    local s2 = sendSettings(); s2.sendMethod = (s2.sendMethod == "log") and "reload" or "log"; updateSendMacros(); fr.refresh()
  end)
  fr:SetHeight(-y + 6)
  fr.refresh = function()
    local s2 = sendSettings()
    fr.ask:SetText("Ask after cooldown: " .. (s2.askAfterCast and "ON" or "OFF"))
    fr.method:SetText("Send method: " .. (s2.sendMethod == "reload" and "Reload" or "Background"))
  end
  return fr
end

toggleMenu = function(anchor)
  if InCombatLockdown() then print(GOLD .. "Professions CDs:|r the menu opens after combat."); return end
  local fr = buildMenu(anchor)
  if not fr then showStatus(); return end
  if fr:IsShown() then fr:Hide(); return end
  fr:ClearAllPoints(); fr:SetPoint("TOPRIGHT", anchor, "BOTTOMLEFT", 0, 0)
  fr.refresh(); fr:Show()
  local token = GetTime(); fr.token = token
  C_Timer.After(15, function() if menu and menu.token == token then safeHide(menu) end end)
end

f:HookScript("OnEvent", function(_, event)
  if event == "PLAYER_REGEN_ENABLED" then
    for fr in pairs(hideAfterCombat) do fr:Hide(); hideAfterCombat[fr] = nil end
    updateSendMacros()
    if popupWanted then popupWanted = false; C_Timer.After(1, showPopup) end
  end
end)
pcall(f.RegisterEvent, f, "PLAYER_REGEN_ENABLED")

local loginHooked = false
local function onLoginInfo()
  if loginHooked then return end
  loginHooked = true
  pcall(buildMinimapButton)
  setTrackerShown(trackerSettings().shown ~= false)
  C_Timer.NewTicker(1, function() pcall(updateTracker) end)
  C_Timer.After(6, function()
    if not DB.welcomed then
      DB.welcomed = true
      showWelcome()
    else
      local c = me()
      if not c.tradeOpened and hasProfessions() then
        print(GOLD .. "Professions CDs:|r open your profession window once on this character so I can track its cooldowns. Type /cds status for details.")
      end
    end
  end)
end
f:HookScript("OnEvent", function(_, event) if event == "PLAYER_ENTERING_WORLD" then onLoginInfo() end end)

SLASH_PROFCDS1 = "/profcds"
SLASH_PROFCDS2 = "/cds"
SlashCmdList.PROFCDS = function(msg)
  msg = (msg or ""):lower()
  if msg:find("help") then showWelcome()
  elseif msg:find("status") then showStatus()
  elseif msg:find("unlock") then trackerSettings().locked = false; print(GOLD .. "Professions CDs:|r tracker unlocked – drag it to move.")
  elseif msg:find("lock") then trackerSettings().locked = true; print(GOLD .. "Professions CDs:|r tracker locked.")
  else toggleTracker() end
end
