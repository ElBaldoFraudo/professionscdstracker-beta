-- Professions CDs Tracker – in-game part
-- 1) Turns on combat logging at login, so the PC helper sees new casts within seconds.
-- 2) Reads each character's profession cooldowns and saves them (WoW writes the file on logout / character switch / reload).
-- Type /profcds in game to see what the addon can see.

local f = CreateFrame("Frame")
local DB

-- Cooldown lengths in seconds (WoW Forever, Nov 2026). Only used until the real cooldown can be read.
local DUR = {
  arcanite = 47 * 3600, legionite = 47 * 3600, elemental = 23 * 3600, onyxia = 2 * 3600, efire = 600,
  ironGold = 3600, mithrilTrue = 3600, salt = 71 * 3600, mooncloth = 95 * 3600, study = 23 * 3600,
}

-- Spells we know the ID of. Others (e.g. Dedicated Study, Legionite) are learned by name
-- the first time they are cast or seen in the profession window.
local SEED_IDS = {
  [17187] = "Transmute: Arcanite", [11479] = "Transmute: Iron to Gold", [11480] = "Transmute: Mithril to Truesilver",
  [17559] = "Transmute: Air to Fire", [17560] = "Transmute: Fire to Earth", [17561] = "Transmute: Earth to Water",
  [17562] = "Transmute: Water to Air", [17563] = "Transmute: Undeath to Water", [17564] = "Transmute: Water to Undeath",
  [17565] = "Transmute: Life to Earth", [17566] = "Transmute: Earth to Life", [25146] = "Transmute: Elemental Fire",
  [18560] = "Mooncloth", [19566] = "Salt Shaker",
}
local NAME_LOOKUPS = { "Dedicated Study", "Transmute: Legionite", "Transmute: Refined Scale of Onyxia" }
local SALT_ITEM = 15846

-- Returns key, variant for a spell/recipe name, or nil.
local function classify(name)
  if type(name) ~= "string" then return nil end
  local t = name:match("^Transmute: (.+)$")
  if t then
    if t == "Iron to Gold" then return "ironGold" end
    if t == "Mithril to Truesilver" then return "mithrilTrue" end
    if t == "Arcanite" then return "transmute", "arcanite" end
    if t == "Legionite" then return "transmute", "legionite" end
    if t == "Elemental Fire" then return "transmute", "efire" end
    if t:find("Onyxia") then return "transmute", "onyxia" end
    return "transmute", "elemental"
  end
  if name == "Salt Shaker" or name == "Refined Deeprock Salt" then return "salt" end
  if name == "Mooncloth" or name == "Create Item: Mooncloth" then return "mooncloth" end
  if name == "Dedicated Study" then return "study" end
  return nil
end

local function isNum(x)
  if type(x) ~= "number" then return false end
  if issecretvalue and issecretvalue(x) then return false end
  return true
end

-- Seconds left from a (start, duration) pair. nil = unknown, 0 = ready.
local function left(start, dur)
  if not isNum(start) or not isNum(dur) then return nil end
  if dur <= 2 or start == 0 then return 0 end -- nothing or just the global cooldown
  local r = start + dur - GetTime()
  return r > 0 and r or 0
end

local function spellLeft(id)
  if C_Spell and C_Spell.GetSpellCooldown then
    local ok, info = pcall(C_Spell.GetSpellCooldown, id)
    if ok and type(info) == "table" then return left(info.startTime, info.duration) end
  end
  if GetSpellCooldown then
    local ok, s, d = pcall(GetSpellCooldown, id)
    if ok then return left(s, d) end
  end
  return nil
end

local function itemLeft(id)
  local fn = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
  if not fn then return nil end
  local ok, s, d = pcall(fn, id)
  if ok then return left(s, d) end
  return nil
end

local function spellName(id)
  if C_Spell and C_Spell.GetSpellName then
    local ok, n = pcall(C_Spell.GetSpellName, id)
    if ok and type(n) == "string" then return n end
  end
  if GetSpellInfo then local ok, n = pcall(GetSpellInfo, id); if ok and type(n) == "string" then return n end end
  return nil
end

local function me()
  local name, realm = UnitFullName("player")
  realm = realm or GetRealmName() or ""
  local id = name .. "-" .. realm
  DB.chars[id] = DB.chars[id] or { name = name, realm = realm, known = {}, cds = {} }
  return DB.chars[id]
end

local function now() return GetServerTime() end

-- Record a cooldown for the current character. secondsLeft = 0 means ready.
local function record(c, key, secondsLeft, variant)
  local t = now()
  local cd = c.cds[key] or {}
  cd.readyAt = secondsLeft > 0 and math.floor(t + secondsLeft) or 0
  if variant then cd.variant = variant end
  cd.observed = t
  c.cds[key] = cd
  if secondsLeft > 0 then c.known[key] = true end
end

local function buildExport()
  local lines = {}
  for _, c in pairs(DB.chars) do
    for key in pairs(c.known) do
      local cd = c.cds[key] or {}
      lines[#lines + 1] = table.concat({ c.name, c.realm, key, cd.variant or "", tostring(cd.readyAt or 0), tostring(cd.observed or 0) }, "|")
    end
  end
  DB.export = table.concat(lines, ";")
  DB.exportedAt = now()
end

local function scan()
  if not DB then return end
  local c = me()
  -- Make sure name lookups have turned into IDs.
  for _, n in ipairs(NAME_LOOKUPS) do
    if C_Spell and C_Spell.GetSpellInfo then
      local ok, info = pcall(C_Spell.GetSpellInfo, n)
      if ok and type(info) == "table" and isNum(info.spellID) then DB.learned[info.spellID] = n end
    end
  end
  local best = {} -- key -> {left, variant}
  local function consider(key, l, variant)
    if l == nil then return end
    local b = best[key]
    if not b or l > b.left then best[key] = { left = l, variant = variant } end
  end
  for id, n in pairs(SEED_IDS) do local key, v = classify(n); consider(key, spellLeft(id), nil) end
  for id, n in pairs(DB.learned) do local key, v = classify(n); consider(key, spellLeft(id), nil) end
  consider("salt", itemLeft(SALT_ITEM), nil)

  for key, b in pairs(best) do
    if b.left > 0 then
      record(c, key, b.left, nil)            -- running: the character clearly has it
    elseif c.known[key] then
      record(c, key, 0, nil)                 -- ready, and we know this character has it
    end
  end
  buildExport()
end

-- Profession window: learn which recipes this character has, and their cooldowns.
local function scanTradeSkill()
  if not (C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs) then return end
  local ok, ids = pcall(C_TradeSkillUI.GetAllRecipeIDs)
  if not ok or type(ids) ~= "table" then return end
  local c = me()
  c.tradeOpened = true
  for _, rid in ipairs(ids) do
    local ok2, info = pcall(C_TradeSkillUI.GetRecipeInfo, rid)
    if ok2 and type(info) == "table" and info.learned then
      local key, variant = classify(info.name)
      if key then
        DB.learned[rid] = info.name
        c.known[key] = true
        if C_TradeSkillUI.GetRecipeCooldown then
          local ok3, cd = pcall(C_TradeSkillUI.GetRecipeCooldown, rid)
          if ok3 and isNum(cd) and cd > 0 then record(c, key, cd, nil) end
        end
      end
    end
  end
  scan()
end

local function enableCombatLog()
  if not LoggingCombat then return end
  local ok, on = pcall(LoggingCombat)
  if ok and not on then pcall(LoggingCombat, true) end
end

local function onCast(spellID)
  local n = spellName(spellID)
  local key, variant = classify(n)
  if not key then return end
  DB.learned[spellID] = n
  local c = me()
  c.known[key] = true
  record(c, key, DUR[variant or key] or DUR[key], variant)
  buildExport()
  C_Timer.After(2, scan) -- replace the estimate with the real cooldown
end

f:SetScript("OnEvent", function(_, event, ...)
  if event == "ADDON_LOADED" then
    if ... == "ProfCDs" then
      ProfCDsDB = ProfCDsDB or {}
      DB = ProfCDsDB
      DB.chars = DB.chars or {}
      DB.learned = DB.learned or {}
      DB.version = 1
    end
  elseif event == "PLAYER_ENTERING_WORLD" then
    enableCombatLog()
    C_Timer.After(3, scan)
  elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
    local unit, _, spellID = ...
    if unit == "player" and isNum(spellID) then onCast(spellID) end
  elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_LIST_UPDATE" then
    C_Timer.After(0.5, scanTradeSkill)
  elseif event == "SPELL_UPDATE_COOLDOWN" or event == "BAG_UPDATE_COOLDOWN" then
    if not InCombatLockdown() then
      if not f.pending then f.pending = true; C_Timer.After(2, function() f.pending = false; scan() end) end
    end
  elseif event == "PLAYER_LOGOUT" then
    if DB then pcall(scan) end
  end
end)
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "UNIT_SPELLCAST_SUCCEEDED", "TRADE_SKILL_SHOW",
  "TRADE_SKILL_LIST_UPDATE", "SPELL_UPDATE_COOLDOWN", "BAG_UPDATE_COOLDOWN", "PLAYER_LOGOUT" }) do
  pcall(f.RegisterEvent, f, e)
end

local NICE = { transmute = "Transmute", ironGold = "Iron to Gold", mithrilTrue = "Mithril to Truesilver", salt = "Salt Shaker", mooncloth = "Mooncloth", study = "Dedicated Study" }
local GOLD, GREEN, RED, GREY = "|cffd9b35f", "|cff6fd39a", "|cffe2736a", "|cff9a98a3"
local function fmt(s)
  if s <= 0 then return GREEN .. "Ready|r" end
  local h = math.floor(s / 3600); local m = math.floor((s % 3600) / 60)
  if h >= 24 then return string.format("%dd %dh %02dm", math.floor(h / 24), h % 24, m) end
  return string.format("%dh %02dm", h, m)
end
local function loggingOn() if not LoggingCombat then return false end local ok, on = pcall(LoggingCombat); return ok and on end
local function hasProfessions()
  if not GetProfessions then return true end
  local ok, a, b = pcall(GetProfessions)
  return ok and (a ~= nil or b ~= nil)
end

local WELCOME = table.concat({
  GOLD .. "Welcome!|r This addon sends your profession cooldowns to the",
  "Professions CDs Tracker app on your phone, so you get a notification",
  "when a transmute, Salt Shaker, Mooncloth or Dedicated Study is ready.",
  "",
  GOLD .. "What you need to do|r",
  "1. On each character with a profession: " .. GOLD .. "open the profession window once|r.",
  "   That lets the addon see which recipes the character has.",
  "2. Play as usual. Use your cooldowns like you always do.",
  "",
  GOLD .. "What happens by itself|r",
  "- Combat logging is turned on at login. New cooldowns reach",
  "  your phone within seconds through the PC helper.",
  "- When you log out or switch character, all cooldowns of that",
  "  character are saved and sent too (this is also how cooldowns",
  "  that were already running get picked up the first time).",
  "",
  GOLD .. "The tracker window|r",
  "- A small window shows all your characters' cooldowns, live.",
  "  Drag it where you want it. It keeps tracking even when hidden.",
  "- Show/hide it with the " .. GOLD .. "minimap button|r (left-click) or " .. GOLD .. "/cds|r.",
  "- " .. GOLD .. "/cds status|r (or right-click the minimap button) shows details.",
  "- " .. GOLD .. "/cds lock|r / " .. GOLD .. "/cds unlock|r locks the window in place.",
  "",
  GOLD .. "Good to know|r",
  "- The PC helper must be installed (install.cmd) and use the same",
  "  sync code as the app.",
}, "\n")

local frame
local function getFrame()
  if frame then return frame end
  local ok, fr = pcall(CreateFrame, "Frame", "ProfCDsFrame", UIParent, "BasicFrameTemplateWithInset")
  if not ok or not fr then ok, fr = pcall(CreateFrame, "Frame", "ProfCDsFrame", UIParent, "BackdropTemplate") end
  if not ok or not fr then return nil end
  frame = fr
  fr:SetSize(470, 540)
  fr:SetPoint("CENTER")
  fr:SetFrameStrata("DIALOG")
  fr:SetMovable(true); fr:EnableMouse(true); fr:RegisterForDrag("LeftButton")
  fr:SetScript("OnDragStart", fr.StartMoving); fr:SetScript("OnDragStop", fr.StopMovingOrSizing)
  if fr.SetBackdrop and not fr.TitleBg then
    fr:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32, insets = { left = 8, right = 8, top = 8, bottom = 8 } })
  end
  fr.title = fr:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  fr.title:SetPoint("TOP", 0, -6)
  fr.title:SetText("Professions CDs Tracker")
  fr.body = fr:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fr.body:SetPoint("TOPLEFT", 18, -36)
  fr.body:SetPoint("RIGHT", -18, 0)
  fr.body:SetJustifyH("LEFT"); fr.body:SetJustifyV("TOP")
  if fr.body.SetSpacing then fr.body:SetSpacing(3) end
  fr.btn = CreateFrame("Button", nil, fr, "UIPanelButtonTemplate")
  fr.btn:SetSize(120, 24); fr.btn:SetPoint("BOTTOMRIGHT", -16, 14)
  fr.btn:SetText("Got it"); fr.btn:SetScript("OnClick", function() fr:Hide() end)
  fr.help = CreateFrame("Button", nil, fr, "UIPanelButtonTemplate")
  fr.help:SetSize(120, 24); fr.help:SetPoint("BOTTOMLEFT", 16, 14)
  if UISpecialFrames then table.insert(UISpecialFrames, "ProfCDsFrame") end
  return fr
end

local showStatus, showWelcome
showWelcome = function()
  local fr = getFrame()
  if not fr then print(WELCOME) return end
  fr.body:SetText(WELCOME)
  fr.help:SetText("Show status"); fr.help:SetScript("OnClick", function() showStatus() end)
  fr:Show()
end

showStatus = function()
  scan()
  local c = me()
  local lines = {}
  local function add(x) lines[#lines + 1] = x end
  add(GOLD .. "Status for " .. c.name .. "|r")
  add("")
  add((loggingOn() and (GREEN .. "[OK]|r Combat logging is on") or (RED .. "[!]|r Combat logging is off - type /combatlog")))
  if c.tradeOpened then add(GREEN .. "[OK]|r Profession window has been opened on this character")
  elseif hasProfessions() then add(RED .. "[!]|r Open your profession window once on this character")
  else add(GREY .. "[-]|r This character has no profession") end
  add("")
  add(GOLD .. "Cooldowns seen|r")
  local any = false
  for key in pairs(c.known) do
    local cd = c.cds[key] or {}
    add("  " .. (NICE[key] or key) .. (cd.variant and (GREY .. " (" .. cd.variant .. ")|r") or "") .. ":  " .. fmt((cd.readyAt or 0) - now()))
    any = true
  end
  if not any then add(GREY .. "  None yet. Open the profession window, or use a cooldown.|r") end
  add("")
  local others = 0
  for id, oc in pairs(DB.chars) do if oc ~= c then for _ in pairs(oc.known) do others = others + 1; break end end end
  add(GOLD .. "Sending to your phone|r")
  add("  New cooldowns: within seconds (through the PC helper).")
  add("  Everything on this character: when you log out or switch character.")
  add("  Other characters with cooldowns saved: " .. others)
  add("")
  add(GREY .. "Tracker window: /cds or the minimap button.  Lock it: /cds lock|r")
  add(GREY .. "Not updating on the phone? Check that the PC helper is installed and uses|r")
  add(GREY .. "the same sync code as the app (app: Settings > Sync with WoW).|r")
  local fr = getFrame()
  if not fr then for _, l in ipairs(lines) do print(l) end return end
  fr.body:SetText(table.concat(lines, "\n"))
  fr.help:SetText("How it works"); fr.help:SetScript("OnClick", function() showWelcome() end)
  fr:Show()
end

-- ---------- Tracker window (always available; tracking runs whether it is shown or not) ----------
local tracker, trackerRows = nil, {}
local function trackerSettings()
  DB.tracker = DB.tracker or { shown = true, locked = false }
  return DB.tracker
end

local function savePos(fr)
  local p, _, rp, x, y = fr:GetPoint()
  trackerSettings().pos = { p, rp, x, y }
end

local function buildTracker()
  if tracker then return tracker end
  local ok, fr = pcall(CreateFrame, "Frame", "ProfCDsTracker", UIParent, "BackdropTemplate")
  if not ok or not fr then return nil end
  tracker = fr
  fr:SetSize(260, 60)
  local pos = trackerSettings().pos
  if pos then fr:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4]) else fr:SetPoint("RIGHT", UIParent, "RIGHT", -60, 140) end
  fr:SetFrameStrata("MEDIUM")
  fr:SetClampedToScreen(true)
  if fr.SetBackdrop then
    fr:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    fr:SetBackdropColor(0.07, 0.08, 0.11, 0.85)
    fr:SetBackdropBorderColor(0.85, 0.70, 0.37, 0.55)
  end
  fr:SetMovable(true); fr:EnableMouse(true); fr:RegisterForDrag("LeftButton")
  fr:SetScript("OnDragStart", function(self) if not trackerSettings().locked then self:StartMoving() end end)
  fr:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); savePos(self) end)
  fr.title = fr:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fr.title:SetPoint("TOPLEFT", 10, -8)
  fr.title:SetText(GOLD .. "Profession CDs|r")
  local close = CreateFrame("Button", nil, fr, "UIPanelCloseButton")
  close:SetSize(22, 22); close:SetPoint("TOPRIGHT", 2, 2)
  close:SetScript("OnClick", function()
    fr:Hide(); trackerSettings().shown = false
    print(GOLD .. "Professions CDs:|r tracker hidden – still tracking in the background. Show it again with the minimap button or /cds.")
  end)
  return fr
end

local function updateTracker()
  if not tracker or not tracker:IsShown() then return end
  local list, t, mine = {}, now(), me()
  for _, c in pairs(DB.chars) do
    for key in pairs(c.known) do
      local cd = c.cds[key] or {}
      list[#list + 1] = { who = c.name, what = NICE[key] or key, left = (cd.readyAt or 0) - t, mine = (c == mine) }
    end
  end
  table.sort(list, function(a, b) if a.left ~= b.left then return a.left < b.left end return a.who < b.who end)
  if #list == 0 then list[1] = { who = "", what = GREY .. "No cooldowns yet – open a profession window|r", left = nil } end
  for i, e in ipairs(list) do
    local r = trackerRows[i]
    if not r then
      r = { l = tracker:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"), r = tracker:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") }
      r.l:SetJustifyH("LEFT"); r.r:SetJustifyH("RIGHT")
      trackerRows[i] = r
    end
    local y = -28 - (i - 1) * 16
    r.l:ClearAllPoints(); r.l:SetPoint("TOPLEFT", 10, y)
    r.r:ClearAllPoints(); r.r:SetPoint("TOPRIGHT", -10, y)
    local who = e.who ~= "" and ((e.mine and GOLD or "|cffece6d8") .. e.who .. "|r  ") or ""
    r.l:SetText(who .. (e.left and (GREY .. e.what .. "|r") or e.what))
    r.r:SetText(e.left and fmt(e.left) or "")
    r.l:Show(); r.r:Show()
  end
  for i = #list + 1, #trackerRows do trackerRows[i].l:Hide(); trackerRows[i].r:Hide() end
  tracker:SetHeight(36 + #list * 16)
end

local function setTrackerShown(show)
  local fr = buildTracker()
  if not fr then return end
  trackerSettings().shown = show
  if show then fr:Show(); updateTracker() else fr:Hide() end
end
local function toggleTracker()
  local fr = buildTracker()
  if fr then setTrackerShown(not fr:IsShown()) end
end

-- ---------- Minimap button ----------
local function placeMinimapButton(b)
  local a = math.rad(trackerSettings().minimapAngle or 210)
  local r = (Minimap:GetWidth() / 2) + 8
  b:ClearAllPoints()
  b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end
local function buildMinimapButton()
  if not Minimap or _G.ProfCDsMinimapButton then return end
  local ok, b = pcall(CreateFrame, "Button", "ProfCDsMinimapButton", Minimap)
  if not ok or not b then return end
  b:SetSize(31, 31); b:SetFrameStrata("MEDIUM"); b:SetFrameLevel(8)
  local icon = b:CreateTexture(nil, "BACKGROUND")
  icon:SetTexture("Interface\\Icons\\Trade_Alchemy"); icon:SetSize(20, 20); icon:SetPoint("CENTER", 0, 1)
  local border = b:CreateTexture(nil, "OVERLAY")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); border:SetSize(53, 53); border:SetPoint("TOPLEFT")
  b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:RegisterForDrag("LeftButton")
  b:SetScript("OnClick", function(_, btn) if btn == "RightButton" then showStatus() else toggleTracker() end end)
  b:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      local mx, my = Minimap:GetCenter()
      local cx, cy = GetCursorPosition()
      local sc = Minimap:GetEffectiveScale()
      trackerSettings().minimapAngle = math.deg(math.atan2(cy / sc - my, cx / sc - mx))
      placeMinimapButton(self)
    end)
  end)
  b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  b:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Professions CDs Tracker")
    GameTooltip:AddLine("Left-click: show/hide the tracker", 1, 1, 1)
    GameTooltip:AddLine("Right-click: status", 1, 1, 1)
    GameTooltip:AddLine("Drag: move this button", 0.6, 0.6, 0.6)
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  placeMinimapButton(b)
end

local loginHooked = false
local function onLoginInfo()
  if loginHooked then return end
  loginHooked = true
  pcall(buildMinimapButton)
  setTrackerShown(trackerSettings().shown ~= false)
  C_Timer.NewTicker(1, function() pcall(updateTracker) end)
  C_Timer.After(6, function()
    if not DB.welcomed then
      DB.welcomed = true
      showWelcome()
    else
      local c = me()
      if not c.tradeOpened and hasProfessions() then
        print(GOLD .. "Professions CDs:|r open your profession window once on this character so I can track its cooldowns. Type /cds status for details.")
      end
    end
  end)
end
f:HookScript("OnEvent", function(_, event) if event == "PLAYER_ENTERING_WORLD" then onLoginInfo() end end)

SLASH_PROFCDS1 = "/profcds"
SLASH_PROFCDS2 = "/cds"
SlashCmdList.PROFCDS = function(msg)
  msg = (msg or ""):lower()
  if msg:find("help") then showWelcome()
  elseif msg:find("status") then showStatus()
  elseif msg:find("unlock") then trackerSettings().locked = false; print(GOLD .. "Professions CDs:|r tracker unlocked – drag it to move.")
  elseif msg:find("lock") then trackerSettings().locked = true; print(GOLD .. "Professions CDs:|r tracker locked.")
  else toggleTracker() end
end
