Professions CDs Tracker - PC helper

1. Install the addon by hand: unzip ProfCDs-addon.zip and copy the ProfCDs folder into
   World of Warcraft\_forever_\Interface\AddOns
2. Double-click install.cmd and enter your sync code from the app (Settings > Sync with WoW)
3. Start WoW and log in - a welcome window in game explains the rest
4. In game, type /cds any time to see the status

To remove the helper: double-click uninstall.cmd
Helper log: %LOCALAPPDATA%\ProfCDsHelper\helper.log
