# Professions CDs Tracker - remove the PC helper (the addon stays; delete Interface\AddOns\ProfCDs by hand if you want)
$Dest = Join-Path $env:LOCALAPPDATA 'ProfCDsHelper'
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*ProfCDsHelper*helper.ps1*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$lnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'Professions CDs Helper.lnk'
if (Test-Path $lnk) { Remove-Item $lnk -Force }
Start-Sleep -Seconds 1
if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force -ErrorAction SilentlyContinue }
Write-Host 'Professions CDs helper removed.'
Read-Host 'Press Enter to close'
