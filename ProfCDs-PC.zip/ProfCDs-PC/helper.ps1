# Professions CDs Tracker - PC helper
# Runs hidden in the background (started at Windows login by the installer).
# Watches the WoW combat log and the addon's saved file, and sends profession
# cooldowns to your Professions CDs server. Reads nothing else.

$ErrorActionPreference = 'Continue'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $Here 'config.json'
$StatePath  = Join-Path $Here 'state.json'
$LogPath    = Join-Path $Here 'helper.log'

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Write-Log($msg) {
  try {
    if ((Test-Path $LogPath) -and ((Get-Item $LogPath).Length -gt 1MB)) { Move-Item $LogPath "$LogPath.old" -Force }
    Add-Content -Path $LogPath -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg) -Encoding UTF8
  } catch {}
}

# Only one helper at a time.
$mutex = New-Object System.Threading.Mutex($false, 'Local\ProfCDsHelper')
if (-not $mutex.WaitOne(0)) { exit }

$cfg = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$Server = $cfg.server.TrimEnd('/')
$Code = $cfg.code
$WowDir = $cfg.wowDir
$CleanupDays = [int]$cfg.cleanupDays
$LogsDir = Join-Path $WowDir 'Logs'
$AccountDir = Join-Path $WowDir 'WTF\Account'

$state = @{ logFile = ''; offset = 0; svTimes = @{} }
if (Test-Path $StatePath) {
  try {
    $s = Get-Content $StatePath -Raw | ConvertFrom-Json
    $state.logFile = [string]$s.logFile
    $state.offset = [int64]$s.offset
    if ($s.svTimes) { foreach ($p in $s.svTimes.PSObject.Properties) { $state.svTimes[$p.Name] = [int64]$p.Value } }
  } catch {}
}
function Save-State { try { ($state | ConvertTo-Json -Depth 4) | Set-Content -Path $StatePath -Encoding UTF8 } catch {} }

$queue = New-Object System.Collections.ArrayList
$recent = @{}   # dedupe combat log casts: "name|key" -> castAt
$Epoch = [DateTime]::new(1970, 1, 1, 0, 0, 0, [DateTimeKind]::Utc)
function To-Ms([DateTime]$d) { [int64]([DateTime]::SpecifyKind($d.ToUniversalTime(), [DateTimeKind]::Utc) - $Epoch).TotalMilliseconds }
function Now-Ms { To-Ms (Get-Date) }

function Classify([string]$spell) {
  if ($spell -match '^Transmute: (.+)$') {
    $t = $Matches[1]
    switch -Regex ($t) {
      '^Iron to Gold$'          { return ,@('ironGold', $null) }
      '^Mithril to Truesilver$' { return ,@('mithrilTrue', $null) }
      '^Arcanite$'              { return ,@('transmute', 'arcanite') }
      '^Legionite$'             { return ,@('transmute', 'legionite') }
      '^Elemental Fire$'        { return ,@('transmute', 'efire') }
      'Onyxia'                  { return ,@('transmute', 'onyxia') }
      default                   { return ,@('transmute', 'elemental') }
    }
  }
  if ($spell -eq 'Salt Shaker' -or $spell -eq 'Refined Deeprock Salt') { return ,@('salt', $null) }
  if ($spell -eq 'Mooncloth' -or $spell -eq 'Create Item: Mooncloth') { return ,@('mooncloth', $null) }
  if ($spell -eq 'Dedicated Study') { return ,@('study', $null) }
  return $null
}

# Split a combat log CSV payload, respecting quotes.
function Split-Csv([string]$s) {
  $out = New-Object System.Collections.Generic.List[string]
  $sb = New-Object System.Text.StringBuilder
  $q = $false
  foreach ($ch in $s.ToCharArray()) {
    if ($ch -eq '"') { $q = -not $q; continue }
    if ($ch -eq ',' -and -not $q) { $out.Add($sb.ToString()); [void]$sb.Clear(); continue }
    [void]$sb.Append($ch)
  }
  $out.Add($sb.ToString())
  return ,$out
}

$LineRx = '^(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\s+(\d{1,2}):(\d{2}):(\d{2})(?:\.\d+)?(?:[-+]\d+)?\s+(SPELL_CAST_SUCCESS|SPELL_CREATE),(.*)$'
$Prefilter = 'SPELL_(CAST_SUCCESS|CREATE).*(Transmute: |Salt Shaker|Refined Deeprock Salt|Mooncloth|Dedicated Study)'

function Parse-Line([string]$line) {
  if ($line -notmatch $Prefilter) { return }
  if ($line -notmatch $LineRx) { return }
  $mo = [int]$Matches[1]; $da = [int]$Matches[2]; $yr = $Matches[3]
  $hh = [int]$Matches[4]; $mi = [int]$Matches[5]; $ss = [int]$Matches[6]
  $f = Split-Csv $Matches[8]
  if ($f.Count -lt 10) { return }
  $srcName = $f[1]; $flagsHex = $f[2]; $spellName = $f[9]
  try { $flags = [Convert]::ToInt64(($flagsHex -replace '^0x', ''), 16) } catch { return }
  if (($flags -band 0x1) -eq 0 -or ($flags -band 0x400) -eq 0) { return }   # must be ME and a player
  $c = Classify $spellName
  if (-not $c) { return }
  $now = Get-Date
  if ($yr) { $y = [int]$yr; if ($y -lt 100) { $y += 2000 } } else { $y = $now.Year }
  try { $when = Get-Date -Year $y -Month $mo -Day $da -Hour $hh -Minute $mi -Second $ss -Millisecond 0 } catch { return }
  if (-not $yr -and $when -gt $now.AddDays(1)) { $when = $when.AddYears(-1) }
  $castAt = To-Ms $when
  $name = ($srcName -split '-')[0]
  $k = "$name|$($c[0])"
  if ($recent.ContainsKey($k) -and [Math]::Abs($recent[$k] - $castAt) -lt 60000) { return }
  $recent[$k] = $castAt
  [void]$queue.Add(@{ name = $name; key = $c[0]; variant = $c[1]; castAt = $castAt; observedAt = $castAt; source = 'combatlog' })
  Write-Log "Cast seen: $name $($c[0]) $($c[1])"
}

function Read-CombatLog {
  if (-not (Test-Path $LogsDir)) { return }
  $file = Get-ChildItem -Path $LogsDir -Filter 'WoWCombatLog*.txt' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $file) { return }
  if ($file.FullName -ne $state.logFile) { $state.logFile = $file.FullName; $state.offset = 0; Write-Log "Reading $($file.Name)" }
  if ($file.Length -lt $state.offset) { $state.offset = 0 }
  if ($file.Length -eq $state.offset) { return }
  try {
    $fs = [System.IO.File]::Open($file.FullName, 'Open', 'Read', 'ReadWrite,Delete')
    try {
      [void]$fs.Seek($state.offset, 'Begin')
      $max = [Math]::Min(8MB, $file.Length - $state.offset)
      $buf = New-Object byte[] $max
      $n = $fs.Read($buf, 0, $max)
      $last = [Array]::LastIndexOf($buf, [byte]10, $n - 1)
      if ($last -lt 0) { if ($n -ge 8MB) { $state.offset += $n }; return }   # wait for a full line
      $text = [System.Text.Encoding]::UTF8.GetString($buf, 0, $last + 1)
      $state.offset += ($last + 1)
      foreach ($line in $text.Split("`n")) { if ($line.Length -gt 20) { Parse-Line $line.TrimEnd("`r") } }
    } finally { $fs.Close() }
  } catch { Write-Log "Combat log read error: $($_.Exception.Message)" }
}

function Read-SavedVariables {
  if (-not (Test-Path $AccountDir)) { return }
  $files = Get-ChildItem -Path $AccountDir -Recurse -Filter 'ProfCDs.lua' -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -like '*SavedVariables' }
  foreach ($sv in $files) {
    $t = $sv.LastWriteTimeUtc.Ticks
    if ($state.svTimes[$sv.FullName] -eq $t) { continue }
    $state.svTimes[$sv.FullName] = $t
    try {
      $raw = [System.IO.File]::ReadAllText($sv.FullName, [System.Text.Encoding]::UTF8)
      if ($raw -match '\["export"\]\s*=\s*"([^"]*)"') {
        $count = 0
        foreach ($entry in ($Matches[1] -split ';')) {
          $p = $entry -split '\|'
          if ($p.Count -lt 6) { continue }
          $readyAt = [int64]$p[4] * 1000
          $observed = [int64]$p[5] * 1000
          $variant = $null; if ($p[3]) { $variant = $p[3] }
          [void]$queue.Add(@{ name = $p[0]; realm = $p[1]; key = $p[2]; variant = $variant; readyAt = $readyAt; observedAt = $observed; source = 'addon' })
          $count++
        }
        Write-Log "Addon file read: $count cooldowns ($($sv.FullName))"
      }
    } catch { Write-Log "Addon file read error: $($_.Exception.Message)" }
  }
}

function Send-Queue {
  if ($queue.Count -eq 0) { return }
  $body = @{ code = $Code; reports = @($queue.ToArray()) } | ConvertTo-Json -Depth 5 -Compress
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
    $res = Invoke-RestMethod -Uri "$Server/game" -Method Post -Body $bytes -ContentType 'application/json; charset=utf-8' -TimeoutSec 20
    Write-Log "Sent $($queue.Count) report(s), $($res.applied) changed"
    $queue.Clear()
  } catch {
    Write-Log "Send failed (will retry): $($_.Exception.Message)"
    if ($queue.Count -gt 500) { $queue.RemoveRange(0, $queue.Count - 500) }
  }
}

function Cleanup-Logs {
  if ($CleanupDays -le 0 -or -not (Test-Path $LogsDir)) { return }
  $cut = (Get-Date).AddDays(-$CleanupDays)
  Get-ChildItem -Path $LogsDir -Filter 'WoWCombatLog*.txt' -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -lt $cut -and $_.FullName -ne $state.logFile } |
    ForEach-Object { try { Remove-Item $_.FullName -Force; Write-Log "Deleted old log $($_.Name)" } catch {} }
}

Write-Log "Helper started. WoW folder: $WowDir  Server: $Server"
$lastCleanup = [DateTime]::MinValue
$tick = 0
while ($true) {
  try {
    Read-CombatLog
    if ($tick % 3 -eq 0) { Read-SavedVariables }
    Send-Queue
    if (((Get-Date) - $lastCleanup).TotalHours -ge 12) { Cleanup-Logs; $lastCleanup = Get-Date }
    if ($tick % 10 -eq 0) { Save-State; $cut = (Now-Ms) - 600000; foreach ($k in @($recent.Keys)) { if ($recent[$k] -lt $cut) { $recent.Remove($k) } } }
  } catch { Write-Log "Loop error: $($_.Exception.Message)" }
  $tick++
  Start-Sleep -Seconds 3
}
