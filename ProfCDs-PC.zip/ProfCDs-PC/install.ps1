# Professions CDs Tracker - installer (addon + PC helper)
$ErrorActionPreference = 'Stop'
$Src = Split-Path -Parent $MyInvocation.MyCommand.Path
$Server = 'https://profcds-sync.zrn2bfz8vj.workers.dev'
$Dest = Join-Path $env:LOCALAPPDATA 'ProfCDsHelper'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host ''
Write-Host '  Professions CDs Tracker - setup' -ForegroundColor Yellow
Write-Host '  ---------------------------------'
Write-Host ''

# 1. Sync code
$code = ''
while ($code -notmatch '^[A-Z0-9]{6,16}$') {
  $code = (Read-Host '  Enter your sync code (in the app: Settings > Sync)').ToUpper() -replace '[^A-Z0-9]', ''
  if ($code -notmatch '^[A-Z0-9]{6,16}$') { Write-Host '  That does not look like a sync code. Try again.' -ForegroundColor Red }
}

# 2. WoW folder
$wow = 'C:\World of Warcraft\_forever_'
if (-not (Test-Path $wow)) {
  try {
    $base = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Blizzard Entertainment\World of Warcraft' -ErrorAction Stop).InstallPath
    $base = Split-Path -Parent ($base.TrimEnd('\'))
    if (Test-Path (Join-Path $base '_forever_')) { $wow = Join-Path $base '_forever_' }
  } catch {}
}
while (-not (Test-Path (Join-Path $wow 'Interface')) -and -not (Test-Path (Join-Path $wow 'WTF'))) {
  Write-Host "  Could not find WoW Forever at $wow" -ForegroundColor Red
  $wow = Read-Host '  Paste the path to your _forever_ folder (e.g. C:\World of Warcraft\_forever_)'
}
Write-Host "  WoW Forever folder: $wow" -ForegroundColor Green

# 3. Addon check (the addon is installed by hand)
$addonToc = Join-Path $wow 'Interface\AddOns\ProfCDs\ProfCDs.toc'
$addonOk = Test-Path $addonToc
if ($addonOk) { Write-Host '  Addon found: Interface\AddOns\ProfCDs' -ForegroundColor Green }
else { Write-Host '  Addon not found yet - copy the ProfCDs folder into Interface\AddOns (see below)' -ForegroundColor Yellow }

# 4. Stop an older helper, copy the new one
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like '*ProfCDsHelper*helper.ps1*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item -Path (Join-Path $Src 'helper.ps1') -Destination $Dest -Force
Copy-Item -Path (Join-Path $Src 'uninstall.ps1') -Destination $Dest -Force
@{ code = $code; server = $Server; wowDir = $wow; cleanupDays = 3 } | ConvertTo-Json | Set-Content -Path (Join-Path $Dest 'config.json') -Encoding UTF8
Get-ChildItem $Dest | Unblock-File -ErrorAction SilentlyContinue

# 5. Start automatically at Windows login (hidden), and start now
$helper = Join-Path $Dest 'helper.ps1'
$conhost = Join-Path $env:WINDIR 'System32\conhost.exe'
$launchArgs = "--headless powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$helper`""
$startup = [Environment]::GetFolderPath('Startup')
$lnk = Join-Path $startup 'Professions CDs Helper.lnk'
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($lnk)
$sc.TargetPath = $conhost
$sc.Arguments = $launchArgs
$sc.WorkingDirectory = $Dest
$sc.WindowStyle = 7
$sc.Description = 'Professions CDs Tracker helper'
$sc.Save()
Start-Process -FilePath $conhost -ArgumentList $launchArgs -WindowStyle Hidden
Write-Host '  Helper installed and running (starts by itself when you log in to Windows)' -ForegroundColor Green

# 6. Check the server
try {
  $h = Invoke-RestMethod -Uri "$Server/health" -TimeoutSec 15
  if ($h.ok) { Write-Host '  Server reachable' -ForegroundColor Green } else { Write-Host '  Server answered but looks wrong' -ForegroundColor Red }
} catch { Write-Host "  Could not reach $Server : $($_.Exception.Message)" -ForegroundColor Red }

Write-Host ''
if (-not $addonOk) {
  Write-Host '  Remember the addon: unzip ProfCDs-addon.zip and copy the ProfCDs folder to' -ForegroundColor Yellow
  Write-Host "  $wow\Interface\AddOns\ProfCDs" -ForegroundColor Yellow
  Write-Host ''
}
Write-Host '  Done. Start WoW and log in - a welcome window explains the rest.' -ForegroundColor Yellow
Write-Host '  In game, type /cds any time to see the status.'
Write-Host "  Helper log: $Dest\helper.log"
Write-Host ''
Read-Host '  Press Enter to close'
